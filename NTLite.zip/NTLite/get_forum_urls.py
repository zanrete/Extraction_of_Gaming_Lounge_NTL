import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import time

class NTLiteForumScraper:
    def __init__(self):
        self.base_url = "https://www.ntlite.com/community/"
        self.session = requests.Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
    def get_page(self, url):
        """Fetch a page from the forum."""
        try:
            response = self.session.get(url, headers=self.headers)
            response.raise_for_status()
            return response.text
        except Exception as e:
            print(f"Error fetching {url}: {str(e)}")
            return None

    def extract_guide_urls(self, html_content):
        """Extract guide URLs from the page content."""
        soup = BeautifulSoup(html_content, 'html.parser')
        urls = []
        
        # Look for links in the content
        for link in soup.find_all('a', href=True):
            href = link['href']
            if 'threads' in href and 'ntlite.com' in href:
                full_url = href if href.startswith('http') else f"https://www.ntlite.com/community/{href}"
                urls.append({
                    'url': full_url,
                    'title': link.get_text(strip=True)
                })
        
        return urls

    def save_urls(self, urls, filename=None):
        """Save URLs to a file with timestamp."""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"ntlite_guide_urls_{timestamp}.txt"
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("NTLite Guide URLs\n")
            f.write("===============\n\n")
            
            # Group URLs by category
            categories = {
                "Basic Guides": [],
                "Advanced Guides": [],
                "Research and Testing": [],
                "Bugs and Suggestions": [],
                "Miscellaneous": []
            }
            
            for url_data in urls:
                url = url_data['url'].lower()
                title = url_data['title']
                
                if any(keyword in url for keyword in ["beginner", "installing", "optimized"]):
                    categories["Basic Guides"].append(url_data)
                elif any(keyword in url for keyword in ["preset", "iso", "resource", "latency", "cache", "cortana", "update", "quality", "safe", "menu"]):
                    categories["Advanced Guides"].append(url_data)
                elif any(keyword in url for keyword in ["discussion", "research", "testing"]):
                    categories["Research and Testing"].append(url_data)
                elif any(keyword in url for keyword in ["bug", "suggestion"]):
                    categories["Bugs and Suggestions"].append(url_data)
                else:
                    categories["Miscellaneous"].append(url_data)
            
            # Write categorized URLs
            for category, category_urls in categories.items():
                if category_urls:
                    f.write(f"\n{category}\n")
                    f.write("-" * len(category) + "\n")
                    for i, url_data in enumerate(category_urls, 1):
                        f.write(f"{i}. {url_data['title']}\n")
                        f.write(f"   URL: {url_data['url']}\n")
                    f.write("\n")
        
        print(f"\nSaved {len(urls)} URLs to {filename}")

def main():
    print("NTLite Forum URL Extractor")
    print("=========================")
    print("\nThis script will help you find the actual URLs for NTLite guides.")
    print("Please provide the URL of the forum post containing the guides.")
    
    forum_url = input("\nEnter the forum post URL: ").strip()
    
    if not forum_url:
        print("No URL provided!")
        return
        
    scraper = NTLiteForumScraper()
    print("\nFetching forum content...")
    html_content = scraper.get_page(forum_url)
    
    if not html_content:
        print("Failed to fetch forum content!")
        return
        
    print("Extracting URLs...")
    urls = scraper.extract_guide_urls(html_content)
    
    if not urls:
        print("No guide URLs found!")
        return
        
    print(f"\nFound {len(urls)} URLs:")
    for i, url_data in enumerate(urls, 1):
        print(f"{i}. {url_data['title']}")
        print(f"   URL: {url_data['url']}")
    
    save = input("\nSave URLs to file? (y/n): ").lower()
    if save == 'y':
        scraper.save_urls(urls)

if __name__ == "__main__":
    main() 