import re
import pyperclip
import json
from datetime import datetime

def extract_urls(text):
    """Extract URLs from text using regex."""
    # URL pattern that matches http(s) URLs and www URLs
    url_pattern = r'(?:https?://|www\.)[^\s<>"]+'
    urls = re.findall(url_pattern, text)
    return urls

def save_urls(urls, filename=None):
    """Save URLs to a file with timestamp."""
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"extracted_urls_{timestamp}.txt"
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("Extracted URLs\n")
        f.write("=============\n\n")
        
        # Group URLs by category
        categories = {
            "Basic Guides": [],
            "Advanced Guides": [],
            "Research and Testing": [],
            "Bugs and Suggestions": [],
            "Miscellaneous": []
        }
        
        for url in urls:
            if "ntlite.com/community" in url:
                if "threads" in url:
                    if any(keyword in url.lower() for keyword in ["beginner", "installing", "optimized"]):
                        categories["Basic Guides"].append(url)
                    elif any(keyword in url.lower() for keyword in ["preset", "iso", "resource", "latency", "cache", "cortana", "update", "quality", "safe", "menu"]):
                        categories["Advanced Guides"].append(url)
                    elif any(keyword in url.lower() for keyword in ["discussion", "research", "testing"]):
                        categories["Research and Testing"].append(url)
                    elif any(keyword in url.lower() for keyword in ["bug", "suggestion"]):
                        categories["Bugs and Suggestions"].append(url)
                    else:
                        categories["Miscellaneous"].append(url)
        
        # Write categorized URLs
        for category, category_urls in categories.items():
            if category_urls:
                f.write(f"\n{category}\n")
                f.write("-" * len(category) + "\n")
                for i, url in enumerate(category_urls, 1):
                    f.write(f"{i}. {url}\n")
                f.write("\n")
    
    print(f"\nSaved {len(urls)} URLs to {filename}")

def main():
    print("URL Extractor")
    print("=============")
    print("\n1. Go to the NTLite forum")
    print("2. Find the actual URLs for each guide")
    print("3. Copy the URLs to your clipboard")
    print("4. Press Enter when ready to extract URLs")
    print("5. Press Ctrl+C to exit\n")
    
    while True:
        try:
            input("Press Enter to extract URLs from clipboard (Ctrl+C to exit)...")
            text = pyperclip.paste()
            
            if not text:
                print("No text found in clipboard!")
                continue
            
            print("\nClipboard content:")
            print("-" * 50)
            print(text[:500] + "..." if len(text) > 500 else text)
            print("-" * 50)
                
            urls = extract_urls(text)
            
            if not urls:
                print("\nNo URLs found in the text!")
                print("Make sure you've copied the actual URLs from the forum.")
                print("The URLs should start with http://, https://, or www.")
                continue
                
            print(f"\nFound {len(urls)} URLs:")
            for i, url in enumerate(urls, 1):
                print(f"{i}. {url}")
            
            save = input("\nSave URLs to file? (y/n): ").lower()
            if save == 'y':
                save_urls(urls)
                
        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()