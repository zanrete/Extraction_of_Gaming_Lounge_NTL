# NTLite Forum Guide Downloader

This script downloads guides and their linked content from the NTLite community forum.

## Features

- Downloads guide content from NTLite forum
- Follows links within guides recursively
- Saves content as text files
- Handles rate limiting and server load
- Sanitizes filenames
- Maintains original formatting

## Requirements

- Python 3.6 or higher
- Required packages listed in requirements.txt

## Installation

1. Clone or download this repository
2. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Run the script:
   ```bash
   python ntlite_forum_downloader.py
   ```

2. The script will:
   - Create a directory called "ntlite_guides"
   - Download guides from the specified URLs
   - Follow links within guides (up to 3 levels deep by default)
   - Save each guide as a separate text file

## Configuration

You can modify the following in the script:
- `max_depth`: Maximum depth of link following (default: 3)
- `start_urls`: List of initial guide URLs to download
- `output_dir`: Directory where guides will be saved

## Notes

- The script includes delays between requests to be respectful to the server
- Downloaded URLs are tracked to avoid duplicates
- Content is saved with original formatting preserved
- Filenames are sanitized to be valid on all operating systems

## Error Handling

The script includes basic error handling for:
- Network issues
- Invalid URLs
- Missing content
- File system errors

## Contributing

Feel free to submit issues and enhancement requests! 