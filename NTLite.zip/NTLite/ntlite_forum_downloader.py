import requests
from bs4 import BeautifulSoup
import os
import time
import json
from urllib.parse import urljoin, urlparse
import re
import mimetypes
from pathlib import Path

class NTLiteForumDownloader:
    def __init__(self, base_url="https://www.ntlite.com/community/"):
        self.base_url = base_url
        self.session = requests.Session()
        self.downloaded_urls = set()
        self.output_dir = "ntlite_guides"
        self.media_dir = os.path.join(self.output_dir, "media")
        self.progress_file = "download_progress.json"
        self.create_directories()
        self.load_progress()
        
    def create_directories(self):
        """Create necessary directories."""
        for directory in [self.output_dir, self.media_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory)

    def is_download_link(self, url):
        """Check if URL points to a downloadable file."""
        return any(ext in url.lower() for ext in ['.zip', '.rar', '.7z', '.exe', '.msi', '.pdf'])

    def is_image_link(self, url):
        """Check if URL points to an image."""
        return any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'])

    def is_article_link(self, url):
        """Check if URL points to an article."""
        return any(keyword in url.lower() for keyword in ['article', 'guide', 'tutorial'])

    def is_comment_link(self, url):
        """Check if URL points to a comment."""
        return 'post-' in url or '#post-' in url

    def download_file(self, url, content_type):
        """Download a file and return its local path."""
        try:
            response = self.session.get(url, stream=True)
            response.raise_for_status()
            
            # Generate filename from URL
            filename = os.path.basename(urlparse(url).path)
            if not filename:
                filename = f"download_{len(self.downloaded_urls)}"
            
            # Add appropriate extension if missing
            if not os.path.splitext(filename)[1]:
                ext = mimetypes.guess_extension(content_type) or '.bin'
                filename = f"{filename}{ext}"
            
            filepath = os.path.join(self.media_dir, filename)
            
            # Download the file
            with open(filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            return filepath
        except Exception as e:
            print(f"Error downloading file {url}: {str(e)}")
            return None

    def download_page(self, url):
        """Download a single page and extract its content."""
        if url in self.downloaded_urls:
            return None
            
        try:
            print(f"Downloading: {url}")
            response = self.session.get(url)
            response.raise_for_status()
            self.downloaded_urls.add(url)
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Determine content type and handle accordingly
            if self.is_download_link(url):
                return self.handle_download(url, soup)
            elif self.is_image_link(url):
                return self.handle_image(url, soup)
            elif self.is_article_link(url):
                return self.handle_article(url, soup)
            elif self.is_comment_link(url):
                return self.handle_comment(url, soup)
            else:
                return self.handle_forum_post(url, soup)
            
        except Exception as e:
            print(f"Error downloading {url}: {str(e)}")
            return None

    def handle_download(self, url, soup):
        """Handle download links."""
        description = soup.find('div', class_='bbWrapper')
        if description:
            description = description.get_text(strip=True)
        else:
            description = "Download available"
            
        return {
            'type': 'download',
            'title': os.path.basename(urlparse(url).path),
            'content': f"Download Link: {url}\n\nDescription: {description}",
            'links': []
        }

    def handle_image(self, url, soup):
        """Handle image links."""
        local_path = self.download_file(url, 'image')
        if local_path:
            return {
                'type': 'image',
                'title': os.path.basename(local_path),
                'content': f"![Image]({os.path.relpath(local_path, self.output_dir)})",
                'links': []
            }
        return None

    def handle_article(self, url, soup):
        """Handle article links."""
        # Check if it's a specific section
        if '#' in url:
            section_id = url.split('#')[1]
            content = soup.find(id=section_id)
        else:
            content = soup.find('article') or soup.find('div', class_='bbWrapper')
            
        if not content:
            return None
            
        title = soup.find('h1')
        title_text = title.text.strip() if title else 'Article'
        
        return {
            'type': 'article',
            'title': title_text,
            'content': content.get_text(separator='\n', strip=True),
            'links': self.extract_links(content)
        }

    def handle_comment(self, url, soup):
        """Handle comment links."""
        comment_id = url.split('#post-')[-1] if '#post-' in url else url.split('post-')[-1]
        comment = soup.find(id=f'post-{comment_id}')
        
        if not comment:
            return None
            
        content = comment.find('div', class_='bbWrapper')
        if not content:
            return None
            
        return {
            'type': 'comment',
            'title': f"Comment {comment_id}",
            'content': content.get_text(separator='\n', strip=True),
            'links': self.extract_links(content)
        }

    def handle_forum_post(self, url, soup):
        """Handle forum post links."""
        content = soup.find('div', class_='bbWrapper')
        if not content:
            return None
            
        title = soup.find('h1')
        title_text = title.text.strip() if title else 'Forum Post'
        
        # Check for attachments
        attachments = soup.find_all('a', class_='attachment')
        attachment_links = []
        for attachment in attachments:
            attachment_url = urljoin(self.base_url, attachment['href'])
            attachment_links.append(f"Attachment: {attachment_url}")
        
        return {
            'type': 'forum_post',
            'title': title_text,
            'content': content.get_text(separator='\n', strip=True) + '\n\n' + '\n'.join(attachment_links),
            'links': self.extract_links(content)
        }

    def extract_links(self, content):
        """Extract relevant links from content."""
        links = []
        for link in content.find_all('a', href=True):
            href = link['href']
            if href.startswith('/') or href.startswith(self.base_url):
                full_url = urljoin(self.base_url, href)
                if full_url.startswith(self.base_url) and full_url not in self.downloaded_urls:
                    links.append(full_url)
        return links

    def save_content(self, content, title, content_type):
        """Save content to a text file."""
        if not content:
            return
            
        filename = self.sanitize_filename(title)
        filepath = os.path.join(self.output_dir, f"{filename}.txt")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"{title}\n{'='*len(title)}\n")
            f.write(f"Content Type: {content_type}\n\n")
            f.write(content)
            
        print(f"Saved: {filepath}")

    def download_attachment(self, url):
        """Download a forum attachment."""
        try:
            print(f"Downloading attachment: {url}")
            response = self.session.get(url, stream=True)
            response.raise_for_status()
            
            # Get filename from Content-Disposition header or URL
            content_disposition = response.headers.get('content-disposition')
            if content_disposition:
                filename = re.findall("filename=(.+)", content_disposition)[0].strip('"')
            else:
                filename = os.path.basename(urlparse(url).path)
            
            if not filename:
                filename = f"attachment_{len(self.downloaded_urls)}"
            
            filepath = os.path.join(self.media_dir, filename)
            
            # Download the file
            with open(filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            print(f"Saved attachment: {filepath}")
            return filepath
            
        except Exception as e:
            print(f"Error downloading attachment {url}: {str(e)}")
            return None

    def process_url(self, url, depth=0, max_depth=3):
        """Process a URL and download its attachments."""
        if url in self.downloaded_urls:
            return
            
        try:
            print(f"Processing: {url}")
            response = self.session.get(url)
            response.raise_for_status()
            self.downloaded_urls.add(url)
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all attachment links
            attachments = soup.find_all('a', class_='attachment')
            for attachment in attachments:
                attachment_url = urljoin(self.base_url, attachment['href'])
                if attachment_url not in self.downloaded_urls:
                    self.download_attachment(attachment_url)
                    time.sleep(1)  # Be nice to the server
            
            # Save progress after each page
            self.save_progress()
            
        except Exception as e:
            print(f"Error processing {url}: {str(e)}")

    def download_guides(self, start_urls, max_depth=3):
        """Download attachments from the given URLs."""
        total_urls = len(start_urls)
        for i, url in enumerate(start_urls, 1):
            print(f"\nProcessing guide {i}/{total_urls}: {url}")
            self.process_url(url, max_depth=max_depth)
            time.sleep(2)  # Pause between guides

    def sanitize_filename(self, title):
        """Convert title to a valid filename."""
        # Remove invalid characters
        filename = re.sub(r'[<>:"/\\|?*]', '', title)
        # Replace spaces with underscores
        filename = filename.replace(' ', '_')
        # Limit length and ensure it's not empty
        filename = filename[:200] if filename else 'untitled'
        return filename

    def load_progress(self):
        """Load previously downloaded URLs from progress file."""
        if os.path.exists(self.progress_file):
            try:
                with open(self.progress_file, 'r') as f:
                    self.downloaded_urls = set(json.load(f))
                print(f"Loaded {len(self.downloaded_urls)} previously downloaded URLs")
            except Exception as e:
                print(f"Error loading progress: {str(e)}")
                
    def save_progress(self):
        """Save downloaded URLs to progress file."""
        try:
            with open(self.progress_file, 'w') as f:
                json.dump(list(self.downloaded_urls), f)
        except Exception as e:
            print(f"Error saving progress: {str(e)}")

    def login(self, username, password):
        """Login to the NTLite forum."""
        try:
            # Use the correct XenForo login URL
            login_url = urljoin(self.base_url, "index.php?login/")
            print(f"Accessing login page: {login_url}")
            
            # Set proper headers for initial request
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
            
            response = self.session.get(login_url, headers=headers)
            response.raise_for_status()
            
            # Print response status and content type for debugging
            print(f"Login page response: {response.status_code} - {response.headers.get('content-type', 'unknown')}")
            
            # Find the login form and extract any necessary tokens
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Get CSRF token from the page
            csrf_token = soup.find('input', {'name': '_xfToken'})
            if not csrf_token:
                print("Could not find CSRF token")
                return False
            
            # Find the login form (XenForo 2.3 specific)
            form = soup.find('form', {'class': 'block'})
            if not form:
                print("Could not find login form")
                return False
            
            print("Found login form!")
            
            # Get the form action URL
            action_url = form.get('action', '')
            if not action_url.startswith('http'):
                action_url = urljoin(self.base_url, action_url)
            print(f"Form action URL: {action_url}")
            
            # Get any hidden form fields
            hidden_fields = {}
            for hidden in form.find_all('input', type='hidden'):
                name = hidden.get('name', '')
                value = hidden.get('value', '')
                if name and value:
                    hidden_fields[name] = value
                    print(f"Found hidden field: {name} = {value}")
            
            # Prepare login data for XenForo 2.3
            login_data = {
                'login': username,
                'password': password,
                'remember': '1',
                'redirect': self.base_url,
                '_xfToken': csrf_token.get('value', ''),
                **hidden_fields
            }
            
            # Update headers for POST request
            headers.update({
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': self.base_url,
                'Referer': login_url,
                'X-Requested-With': 'XMLHttpRequest'
            })
            
            print("Attempting login...")
            response = self.session.post(action_url, data=login_data, headers=headers)
            response.raise_for_status()
            
            print(f"Login response: {response.status_code} - {response.headers.get('content-type', 'unknown')}")
            
            # Check if login was successful
            if "Invalid username or password" in response.text:
                print("Login failed: Invalid credentials")
                return False
                
            # Check for successful login indicators
            if "Welcome back" in response.text or "Log out" in response.text:
                print("Login successful!")
                return True
            else:
                print("Login may have failed - please check if you can access attachments")
                return True  # Continue anyway as some forums don't show clear success messages
            
        except Exception as e:
            print(f"Login error: {str(e)}")
            if hasattr(e, 'response'):
                print(f"Response status: {e.response.status_code}")
                print(f"Response headers: {e.response.headers}")
                print(f"Response content: {e.response.text[:500]}")  # Print first 500 chars of error response
            return False

def main():
    # Read URLs from the extracted file
    urls_file = "ntlite_guide_urls_20250305_171056.txt"
    start_urls = []
    
    try:
        with open(urls_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.startswith('   URL: '):
                    start_urls.append(line[7:].strip())
    except Exception as e:
        print(f"Error reading URLs file: {str(e)}")
        return
    
    if not start_urls:
        print("No URLs found in the file!")
        return
        
    print(f"Found {len(start_urls)} URLs to process")
    downloader = NTLiteForumDownloader()
    
    # Ask for login credentials
    username = input("Enter your NTLite forum username (or press Enter to skip login): ").strip()
    if username:
        password = input("Enter your NTLite forum password: ").strip()
        if not downloader.login(username, password):
            print("Login required for attachments. Exiting...")
            return
    
    downloader.download_guides(start_urls)

if __name__ == "__main__":
    main() 